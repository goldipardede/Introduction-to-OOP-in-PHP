<?php

class coba
{
    //property
    public $a;
    
    // method
    public function b()
    {

    }
}

?>